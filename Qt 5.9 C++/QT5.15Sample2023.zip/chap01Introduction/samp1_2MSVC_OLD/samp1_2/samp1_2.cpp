#include "samp1_2.h"

samp1_2::samp1_2(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
