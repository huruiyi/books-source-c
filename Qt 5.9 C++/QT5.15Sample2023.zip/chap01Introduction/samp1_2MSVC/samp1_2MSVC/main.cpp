#include "samp1_2.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    samp1_2 w;
    w.show();
    return a.exec();
}
