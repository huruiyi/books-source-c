#include "samp1_2.h"

samp1_2::samp1_2(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
}

samp1_2::~samp1_2()
{}
