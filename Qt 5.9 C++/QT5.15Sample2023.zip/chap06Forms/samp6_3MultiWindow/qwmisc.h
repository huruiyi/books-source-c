#ifndef QWMISC_H
#define QWMISC_H

#include    <QString>

namespace WWB {

//    QString extractFileName(const   QString& aFileName);//提取文件名
    QString extractFilePath(const   QString& aFileName);//提取文件路径
}

//class QWMisc
//{
//public:
//    QWMisc();
//};

#endif // QWMISC_H
