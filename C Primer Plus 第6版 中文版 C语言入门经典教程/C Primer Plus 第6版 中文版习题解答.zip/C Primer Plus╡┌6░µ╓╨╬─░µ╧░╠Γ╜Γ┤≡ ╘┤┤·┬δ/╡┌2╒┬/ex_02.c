/*
第二章：编程练习 2
*/
#include <stdio.h>
#define NAME "Stephen Prata"
#define ADDRESS "No.11 Chengshou Street, Fengtai District, Beijing"
/*
    姓名、地址分别用预编译指令定义。
*/
int main(void) {

    printf("%s\n",NAME);
    /* 打印姓名 */
    printf("%s\n",ADDRESS);
    /* 打印地址 */
    return 0;
}
