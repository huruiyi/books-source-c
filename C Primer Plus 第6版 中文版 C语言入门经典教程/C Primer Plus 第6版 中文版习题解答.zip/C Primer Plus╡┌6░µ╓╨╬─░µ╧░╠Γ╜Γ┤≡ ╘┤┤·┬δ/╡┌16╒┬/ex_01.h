/*
第十六章：编程练习 1
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define LENGTH 100

char * s_gets(char * st, int n);
typedef struct{
    char first[40];
    char last[40];
}NAME;

