/*
第三章：编程练习 3
*/
#include <stdio.h>
int main(void) {
    char ch = '\a';
    printf("%c",ch);
    /* 输出字符 '\a' 该字符表示警报，但部分系统可能无法发声。*/
    printf("Starled by the sudden sound, Sally shouted, \n");
    printf("\"By the Great Pumpkin, what was that!\"\n");
    return 0;
}
