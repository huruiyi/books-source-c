// Copyright (c) 2021 by Chrono

#ifndef _COMMON_STD_HPP
#define _COMMON_STD_HPP

#include <cassert>

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>

//never 'using namespace std;' in c++ header

#endif  //_COMMON_STD_HPP

