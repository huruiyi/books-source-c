// Copyright (c) 2021 by Chrono
//
// g++ oop.cpp -std=c++17 -o a.out;./a.out
// g++ oop.cpp -std=c++20 -o a.out;./a.out
//

#include <iostream>
#include <string>
#include <vector>
#include <set>

#if 1

class Interface {};

class Implement final : public Interface
{
public:
    using super_type = Interface;
    using this_type  = Implement;
private:
};

#endif

#if 1

struct KafkaConfig final
{
    int             id;
    std::string     ip_addr;
};

class DemoClass final
{
public:
    using this_type         = DemoClass;
    using kafka_conf_type   = KafkaConfig;

public:
    using string_type   = std::string;
    using uint32_type   = uint32_t;

    using set_type      = std::set<int>;
    using vector_type   = std::vector<std::string>;

public:
    DemoClass() = default;
   ~DemoClass() = default;

    DemoClass(const DemoClass&) = delete;
    DemoClass& operator=(const DemoClass&) = delete;
public:
    explicit DemoClass(const string_type& str)
    {
        m_name = str;
    }
    explicit operator bool ()
    {
        return !m_name.empty();
    }
public:
    void set_name(const string_type& str);

private:
    string_type     m_name  = "tom";
    uint32_type     m_age   = 23;
    set_type        m_books;

private:
    kafka_conf_type m_conf;
};

#endif

#if 1

class DemoDelegating final
{
private:
    int a;
public:
    DemoDelegating(int x) : a(x)
    {}

    DemoDelegating() : DemoDelegating(0)
    {}

    DemoDelegating(const std::string& s) : DemoDelegating(std::stoi(s))
    {}
};

#endif

#if 1

class DemoInit final
{
private:
    int                 a = 0;
    std::string         s = "hello";
    std::vector<int>    v{1, 2, 3};
public:
    static const
    int                 x = 0;

    inline static
    std::string         prefix = "/home";
    //static std::string         prefix;
public:
    DemoInit() = default;
   ~DemoInit() = default;
public:
    DemoInit(int x) : a(x) {}
};
//std::string DemoInit::prefix = "/home";

#endif


int main()
{
    using namespace std;

    //DemoClass obj = "sting ctor";
    DemoClass obj = (DemoClass)"sting ctor";

    //bool b = obj;
    bool b = static_cast<bool>(obj);
    if (obj) {
        cout << "explicit bool ok" << endl;
    }

    cout << DemoInit::prefix << endl;

    cout << "show your class." << endl;
}
