/*第二章：编程练习1 */
#include <iostream>
using namespace std;
/* 预编译指令*/

int main() 
{
/* main()函数 */
    cout<<"< C++ Primer Plus > auther: Stephen Prata";
    cout<<endl;
    /* 标准输出打印字符，第二行代码endl表示换行。 */
    return 0;
}
/* main()函数结束，注意函数返回值和表示结束的花括号 */

